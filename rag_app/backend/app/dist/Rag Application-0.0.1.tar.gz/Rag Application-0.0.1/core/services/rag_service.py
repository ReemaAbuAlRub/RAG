from sentence_transformers import SentenceTransformer
from core.services.document_service import DocumentService

class RagService:
    
    def __init__(self,document_service: DocumentService):
        self.document_service = document_service
        self.model = self.document_service.model

    def query(self, query_text: str, top_k: int = 5) -> dict:
        query_embedding = self.model.encode(query_text)
        retrieved_docs = self.document_service.vector_store.search(query_embedding, top_k)
        return {"query": query_text, "retrieved_documents": retrieved_docs}