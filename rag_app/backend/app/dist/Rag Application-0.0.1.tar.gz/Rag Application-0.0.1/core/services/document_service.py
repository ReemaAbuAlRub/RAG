from fastapi import UploadFile
from sentence_transformers import SentenceTransformer
import numpy as np
from adapters.vector_store import VectorStore

class DocumentService:

    def __init__(self, model_name = 'all-MiniLM-L6-v2': str):
        self.model = SentenceTransformer(model_name)
        self.embedding_dim = self.model.get_sentence_embedding_dimension()
        self.vector_store = VectorStore(self.embedding_dim)

    async def upload_document(self, file: UploadFile):
        text = file.file.read().decode('utf-8')
        embedding = self.model.encode(text)
        self.vector_store.add_document(embedding, text)
        return {"status": "success", "message": "Document uploaded and stored."}
