from fastapi import APIRouter, UploadFile, File, HTTPException
from core.services.document_service import DocumentService
from app.dependencies import document_service 

router = APIRouter()

@router.post("/upload")
async def upload_document(file: UploadFile = File(...)):
    try:
        result = await document_service.process_upload(file)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
