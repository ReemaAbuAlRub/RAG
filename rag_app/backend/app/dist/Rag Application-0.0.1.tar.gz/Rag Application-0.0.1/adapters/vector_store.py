import faiss
import numpy as np

class VectorStore:
    def __init__(self, embedding_dim: int):
        self.index = faiss.IndexFlatL2(embedding_dim)
        self.documents = []

    def add_document(self, embedding: np.ndarray, doc_text: str):
        if embedding.ndim == 1:
            embedding = embedding.reshape(1, -1)
        self.index.add(embedding)
        self.documents.append(doc_text)

    def search(self, query_embedding: np.ndarray, top_k: int = 5) -> list:
        if query_embedding.ndim == 1:
            query_embedding = query_embedding.reshape(1, -1)
        _, indices = self.index.search(query_embedding, top_k)
        results = [self.documents[i] for i in indices[0] if i < len(self.documents)]
        return results
